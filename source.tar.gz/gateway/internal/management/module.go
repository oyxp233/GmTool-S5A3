// Package management assembles the gateway's private management module.
package management

import (
	"context"
	"database/sql"
	"errors"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"dnf90.local/gateway/internal/modules/dnf/adminapi"
	dnfpvf "dnf90.local/gateway/internal/modules/dnf/pvf"
	"dnf90.local/gateway/internal/modules/dnf/repository"
	"dnf90.local/gateway/internal/modules/dnf/repository/mysql"
	"dnf90.local/gateway/internal/modules/dnf/testbenefits"
	platformpvf "dnf90.local/gateway/internal/platform/pvf"
	"dnf90.local/gateway/internal/services/gmtool"
)

type Module struct {
	Handler         http.Handler
	server          *gmtool.Server
	archive         *platformpvf.DiskArchive
	clearProjection *mysql.ClearHistoryProjection
	pools           map[string]*sql.DB
	cancel          context.CancelFunc
	done            chan struct{}
	once            sync.Once
}

func resolveClearSnapshotPath(cfg Config) string {
	if envPath := strings.TrimSpace(os.Getenv("PURPLEMAGIC_CLEAR_SNAPSHOT_PATH")); envPath != "" {
		if envPath == "none" || envPath == "memory" {
			return ""
		}
		return envPath
	}
	if cfg.SessionStorePath != "" {
		return filepath.Join(filepath.Dir(cfg.SessionStorePath), "clear-history-v1.snap")
	}
	if cfg.ItemIndexPath != "" {
		return filepath.Join(filepath.Dir(cfg.ItemIndexPath), "clear-history-v1.snap")
	}
	if cacheDir, err := os.UserCacheDir(); err == nil && cacheDir != "" {
		dir := filepath.Join(cacheDir, "purplemagic")
		if os.MkdirAll(dir, 0o700) == nil {
			return filepath.Join(dir, "clear-history-v1.snap")
		}
	}
	return filepath.Join(os.TempDir(), "purplemagic-clear-history-v1.snap")
}

func Open(ctx context.Context, cfg Config, log func(string, ...any)) (_ *Module, result error) {
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	if log == nil {
		log = func(string, ...any) {}
	}
	workerCtx, cancel := context.WithCancel(ctx)
	m := &Module{pools: make(map[string]*sql.DB), cancel: cancel, done: make(chan struct{})}
	started := false
	defer func() {
		if result != nil {
			if !started {
				close(m.done)
			}
			m.Close()
		}
	}()
	var err error
	var source dnfpvf.Source
	var catalog *gmtool.RemoteCatalog
	if cfg.Catalog != nil {
		catalog, err = gmtool.NewRemoteCatalog(*cfg.Catalog)
		if err != nil {
			return nil, err
		}
		source = catalog
	} else {
		m.archive, err = platformpvf.OpenDisk(cfg.PVFPath, cfg.DiskIndexPath(), cfg.PVFSHA256)
		if err != nil {
			return nil, errors.New("management PVF disk index unavailable or mismatched")
		}
		source = m.archive
	}
	pool := func(dsn string) (*sql.DB, error) {
		if db := m.pools[dsn]; db != nil {
			return db, nil
		}
		db, e := sql.Open("mysql", dsn)
		if e != nil {
			return nil, errors.New("management database configuration invalid")
		}
		db.SetMaxOpenConns(16)
		db.SetMaxIdleConns(16)
		db.SetConnMaxLifetime(15 * time.Minute)
		db.SetConnMaxIdleTime(5 * time.Minute)
		m.pools[dsn] = db
		check, stop := context.WithTimeout(ctx, 5*time.Second)
		defer stop()
		if e = db.PingContext(check); e != nil {
			return nil, errors.New("management database unavailable")
		}
		return db, nil
	}
	registration, err := pool(cfg.RegistrationDSN)
	if err != nil {
		return nil, err
	}
	data, err := pool(cfg.RepositoryDSN)
	if err != nil {
		return nil, err
	}
	if err = mysql.CheckManagementSchema(ctx, data, mysql.MySQLGroupOptions{TablePrefix: cfg.TablePrefix, DatabasePlan: repository.DatabasePlan{WriteDatabases: cfg.Databases, ReadDatabases: cfg.Databases}}); err != nil {
		return nil, errors.New("management receipt schema unavailable; run --init-management-schema")
	}
	group, err := mysql.NewMySQLGroupFromDB(data, mysql.MySQLGroupOptions{
		TablePrefix:  cfg.TablePrefix,
		DatabasePlan: repository.DatabasePlan{WriteDatabases: cfg.Databases, ReadDatabases: cfg.Databases},
		ClearProjection: &mysql.ClearProjectionConfig{
			SnapshotPath: resolveClearSnapshotPath(cfg),
			Logger:       log,
		},
	})
	if err != nil {
		return nil, errors.New("management repository mapping invalid")
	}
	m.clearProjection = mysql.ClearProjectionFromGroup(group)
	benefits, err := testbenefits.NewStore(registration, cfg.AccountTable)
	if err != nil {
		return nil, err
	}
	// 福利前缀是账号表名，跟角色表前缀不是一回事；等级达标规则要给全角色拍基线，
	// 所以得把真正的角色表名告诉它。
	benefits.SetCharacterTable(cfg.TablePrefix + "_characters")
	if _, err = benefits.Campaigns(ctx); err != nil {
		return nil, errors.New("management benefit schema unavailable; initialize during installation")
	}
	if err = benefits.CheckPVFReviewSchema(ctx); err != nil {
		return nil, errors.New("management benefit PVF history schema unavailable; run --init-management-schema")
	}
	runtime, err := adminapi.NewClient(cfg.GameAPI, cfg.GameToken)
	if err != nil {
		return nil, err
	}
	deps := gmtool.Deps{Catalog: catalog, RegistrationDB: registration, Runtime: runtime, Benefits: benefits, Repos: func() (repository.Group, bool) { return group, true }, PVF: func() (dnfpvf.Source, error) { return source, nil }}
	deps.PremiumTypes = func() ([]int64, error) {
		r, e := runtime.Call(workerCtx, adminapi.Request{Action: "catalog"})
		return r.PremiumTypes, e
	}
	deps.CrystalCubeItemIDs = func() ([6]int64, error) {
		r, e := runtime.Call(workerCtx, adminapi.Request{Action: "catalog"})
		return r.CrystalCubeItemIDs, e
	}
	secret := cfg.Password
	if cfg.LoginKeySHA256 != "" {
		secret = cfg.LoginKeySHA256
	}
	m.server, err = gmtool.NewManaged(ctx, gmtool.Config{Password: secret, LoginKeySHA256: cfg.LoginKeySHA256, SessionStorePath: cfg.SessionStorePath, Table: cfg.AccountTable, PVFPath: cfg.PVFPath, ItemIndexCachePath: cfg.ItemIndexPath, DatabaseLabel: "MariaDB", RequireOffline: true, Logger: log}, deps)
	if err != nil {
		return nil, err
	}
	if m.clearProjection != nil {
		m.clearProjection.Start(workerCtx)
	}
	if cfg.Catalog != nil {
		m.Handler = m.server.GatewayHandler(cfg.ServiceToken, cfg.PVFSHA256)
		// ★ catalog 模式同样要起福利扫描 worker。
		//
		// 线上 gateway.json 里 management.catalog 指向 GMService 的 28081，
		// 于是永远走这个分支；而这个分支原来直接 close(m.done) 返回，
		// 两个扫描 goroutine 全被跳过 —— 而 GMService 是纯代理（无 DB、
		// 无 benefit scheduling），结果**全服没有任何进程在跑福利扫描**：
		// 等级达标规则从不发放，且不报任何错。2026-11-12 实测
		// 1351 行基线 delivered_at 全为 NULL、benefit_jobs 无一条等级记录。
		//
		// worker 只依赖福利库 + 角色仓储 + admin API，与 PVF catalog 无关。
		started = true
		m.startBenefitWorkers(workerCtx, cfg, log)
		return m, nil
	}
	m.Handler = m.server.ManagementHandler(cfg.WebRoot)
	started = true
	m.startBenefitWorkers(workerCtx, cfg, log)
	return m, nil
}

// startBenefitWorkers 启动福利扫描的两条通道。
//
// 幂等性由调用点保证（每个 Module 只调一次）：慢扫描 goroutine 负责
// close(m.done)，所以**绝不能重复调用**，否则 Close 会 panic 在重复 close。
func (m *Module) startBenefitWorkers(workerCtx context.Context, cfg Config, log func(string, ...any)) {
	// 等级达标规则的快速通道：独立 10 秒 ticker。
	// 账号轮询要 60 秒一轮、且一轮只处理 50 个账号，玩家升级后可能要等很久；
	// 这条只查"创建时未达标、现在已达标、还没发过"的角色，代价很小。
	go func() {
		ticker := time.NewTicker(benefitLevelScanInterval)
		defer ticker.Stop()
		for {
			select {
			case <-workerCtx.Done():
				return
			case <-ticker.C:
				ctx, cancel := context.WithTimeout(workerCtx, 8*time.Second)
				if e := m.server.ScanLevelBenefitCandidates(ctx, 100); e != nil && workerCtx.Err() == nil {
					log("management-benefit-level-scan-retry", "error", e.Error())
				}
				cancel()
			}
		}
	}()
	go func() {
		defer close(m.done)
		timer := time.NewTimer(cfg.scanInterval())
		defer timer.Stop()
		var cursor int64
		for {
			select {
			case <-workerCtx.Done():
				return
			case <-timer.C:
				scan, stop := context.WithTimeout(workerCtx, 20*time.Second)
				var e error
				cursor, e = m.server.ScanNewCharacters(scan, cursor, 50)
				stop()
				if e != nil && workerCtx.Err() == nil {
					log("management-benefit-scan-retry", "error", e.Error())
				}
				timer.Reset(cfg.scanInterval())
			}
		}
	}()
}

func (m *Module) Close() error {
	var result error
	m.once.Do(func() {
		m.cancel()
		<-m.done
		if m.clearProjection != nil {
			result = errors.Join(result, m.clearProjection.Close())
		}
		if m.server != nil {
			result = errors.Join(result, m.server.Stop())
		}
		for _, db := range m.pools {
			result = errors.Join(result, db.Close())
		}
		if m.archive != nil {
			result = errors.Join(result, m.archive.Close())
		}
	})
	return result
}

// HubSessionGuard shares the integrated management session with Hub settings.
func (m *Module) HubSessionGuard(next http.Handler) http.Handler {
	return m.server.HubHandler(next)
} // benefitLevelScanInterval 是等级达标规则的快速扫描间隔。
// 独立于账号轮询（scanSeconds，线上 60 秒），保证升级后十秒级到账。
const benefitLevelScanInterval = 10 * time.Second
