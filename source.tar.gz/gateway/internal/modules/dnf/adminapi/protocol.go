// Package adminapi defines the private game-runtime management contract.
// It contains no web panel, database connection, scheduler or game transport.
package adminapi

import (
	"dnf90.local/gateway/internal/modules/dnf/moderation"
	"dnf90.local/gateway/internal/modules/dnf/onlineevent"
	"dnf90.local/gateway/internal/modules/dnf/qqbinding"
	"dnf90.local/gateway/internal/modules/dnf/repository"
	"encoding/json"
)

const Version = 1
const Path = "/api/game/admin"

type Request struct {
	InventoryEdit   *InventoryEditRequest       `json:"inventoryEdit,omitempty"`
	QQChange        *qqbinding.Change           `json:"qqChange,omitempty"`
	QQCheck         *qqbinding.CheckResult      `json:"qqCheck,omitempty"`
	PasswordReset   *PasswordReset              `json:"passwordReset,omitempty"`
	QQAck           *moderation.QQAck           `json:"qqAck,omitempty"`
	QQ              string                      `json:"qq,omitempty"`
	QQSettings      *qqbinding.Settings         `json:"qqSettings,omitempty"`
	QQComplete      *qqbinding.Complete         `json:"qqComplete,omitempty"`
	QQQuery         *qqbinding.Query            `json:"qqQuery,omitempty"`
	ModerationQuery *moderation.Query           `json:"moderationQuery,omitempty"`
	BanChange       *moderation.BanChange       `json:"banChange,omitempty"`
	AccountID       string                      `json:"accountId,omitempty"`
	Version         int                         `json:"version"`
	Action          string                      `json:"action"`
	CharacterID     uint16                      `json:"characterId,omitempty"`
	Revision        uint64                      `json:"revision,omitempty"`
	Changes         []onlineevent.ControlChange `json:"changes,omitempty"`
	ListType        byte                        `json:"listType,omitempty"`
	Slot            int16                       `json:"slot,omitempty"`
	Stack           *repository.ItemStack       `json:"stack,omitempty"`

	// ITEM-SELL-OVERRIDE:pvf_override_* action 的入参。
	ItemID   uint32 `json:"itemId,omitempty"`
	SellGold int64  `json:"sellGold,omitempty"`
	Clear    bool   `json:"clear,omitempty"`

	// UPGRADE-SUCCESS-OVERRIDE:upgrade_success_override_* action 的入参。
	Mode   string `json:"mode,omitempty"`
	Level  int    `json:"level,omitempty"`
	Weight int    `json:"weight,omitempty"`

	// EPIC-RATE-OVERRIDE:epic_rate_override_* action 复用 CharacterID（原 Request 字段）。
	RateMultiplier float64 `json:"rateMultiplier,omitempty"`

	// ABYSS-RARITY-TABLE:abyss_rarity_table_override_* action 的入参。
	// ScopeType ∈ {global, account, character}（空 = global）；
	// AbyssRarityRows 是按**百分比**录入的整张 [basis of rarity dicision] 表：
	// 每行 6 个数（rarity 0..5），整行和为 100，行号 = 深渊档位-1。
	ScopeType       string      `json:"scopeType,omitempty"`
	ScopeID         string      `json:"scopeId,omitempty"`
	AbyssRarityRows [][]float64 `json:"abyssRarityRows,omitempty"`

	// AUCTION-BOT:auction_bot_* action 的入参。
	// 配置与清单都用 RawMessage 透传：默认值与钳制规则只在服务端实现一份。
	AuctionBotConfig       json.RawMessage `json:"auctionBotConfig,omitempty"`
	AuctionBotItems        json.RawMessage `json:"auctionBotItems,omitempty"`
	AuctionBotDelistItemID int64           `json:"auctionBotDelistItemId,omitempty"`
	// AUCTION-SALES:auction_sales_list 的入参（返回在 Response 里）。
	AuctionSalesLimit int `json:"auctionSalesLimit,omitempty"`
	// AUCTION-SALE-HISTORY:成交历史查询条件（全部可选）。
	AuctionHistoryItemID    int64  `json:"auctionHistoryItemId,omitempty"`
	AuctionHistoryAccount   string `json:"auctionHistoryAccount,omitempty"`
	AuctionHistoryCharacter string `json:"auctionHistoryCharacter,omitempty"`
	AuctionHistoryKind      string `json:"auctionHistoryKind,omitempty"`
	AuctionHistoryFrom      string `json:"auctionHistoryFrom,omitempty"`
	AuctionHistoryTo        string `json:"auctionHistoryTo,omitempty"`
	AuctionHistoryLimit     int    `json:"auctionHistoryLimit,omitempty"`

	// MAGIC-BOX-OVERRIDE:magic_box_override_set 的入参。ItemID 复用为盒子 item id，
	// MagicBoxRewardGroups 是覆盖后的整组 (item, weight, count) 条目。
	MagicBoxRewardGroups []MagicBoxRewardGroupJSON `json:"magicBoxRewardGroups,omitempty"`

	// GOLD-CONSIGN-BUYBACK:gold_consign_buyback_update 的入参。
	// 原样透传给网关的 /internal/gold-consign-buyback/config（网关不解析字段）。
	GoldConsignBuybackConfig json.RawMessage `json:"goldConsignBuybackConfig,omitempty"`
}

// MagicBoxRewardGroupJSON 是 GM 侧传入/返回的一个覆盖奖励组（item/weight/count）。
type MagicBoxRewardGroupJSON struct {
	ItemID int64 `json:"itemId"`
	Weight int64 `json:"weight"`
	Count  int64 `json:"count"`
}

type Response struct {
	InventoryEdit      *InventoryEditStatus    `json:"inventoryEdit,omitempty"`
	QQChecks           []qqbinding.Check       `json:"qqChecks,omitempty"`
	QQChanged          bool                    `json:"qqChanged,omitempty"`
	PasswordReset      *PasswordResetResult    `json:"passwordReset,omitempty"`
	ErrorCode          string                  `json:"errorCode,omitempty"`
	BanTargets         *moderation.BanTargets  `json:"banTargets,omitempty"`
	QQActions          []moderation.QQAction   `json:"qqActions,omitempty"`
	QQBlocked          bool                    `json:"qqBlocked,omitempty"`
	QQSettings         *qqbinding.Settings     `json:"qqSettings,omitempty"`
	QQBinding          *qqbinding.Binding      `json:"qqBinding,omitempty"`
	QQBindings         *qqbinding.Page         `json:"qqBindings,omitempty"`
	Clears             *moderation.ClearPage   `json:"clears,omitempty"`
	Bans               *moderation.BanPage     `json:"bans,omitempty"`
	Ban                *moderation.Ban         `json:"ban,omitempty"`
	ModerationAccounts *moderation.AccountPage `json:"moderationAccounts,omitempty"`
	CharacterEdit      *CharacterEditStatus    `json:"characterEdit,omitempty"`
	AccountEdit        *AccountEditStatus      `json:"accountEdit,omitempty"`
	OnlineSnapshot     *OnlineSnapshot         `json:"onlineSnapshot,omitempty"`
	// GOLD-CONSIGN-BUYBACK:get/update 两个 action 的返回（网关下发的 envelope）。
	GoldConsignBuybackConfig any                          `json:"goldConsignBuybackConfig,omitempty"`
	Version                  int                          `json:"version"`
	OK                       bool                         `json:"ok"`
	Error                    string                       `json:"error,omitempty"`
	Online                   bool                         `json:"online"`
	Activities               *onlineevent.ControlSnapshot `json:"activities,omitempty"`
	PremiumTypes             []int64                      `json:"premiumTypes,omitempty"`
	CrystalCubeItemIDs       [6]int64                     `json:"crystalCubeItemIds,omitempty"`
	StackRow                 []byte                       `json:"stackRow,omitempty"`

	// ITEM-SELL-OVERRIDE:pvf_override_* action 的返回。
	OverrideCount int              `json:"overrideCount,omitempty"`
	Overrides     map[uint32]int64 `json:"overrides,omitempty"`

	// UPGRADE-SUCCESS-OVERRIDE:upgrade_success_override_* action 的返回。
	SuccessOverrideCount int            `json:"successOverrideCount,omitempty"`
	SuccessOverrides     map[string]int `json:"successOverrides,omitempty"`

	// EPIC-RATE-OVERRIDE:epic_rate_override_* action 的返回。
	EpicRateOverrideCount int                `json:"epicRateOverrideCount,omitempty"`
	EpicRateOverrides     map[string]float64 `json:"epicRateOverrides,omitempty"`

	// ABYSS-RARITY-TABLE:abyss_rarity_table_override_* action 的返回。
	AbyssRarityTableCount int `json:"abyssRarityTableCount,omitempty"`

	// AUCTION-BOT:auction_bot_state 返回配置与清单；delist 返回下架件数。
	AuctionBot         json.RawMessage `json:"auctionBot,omitempty"`
	AuctionBotDelisted int             `json:"auctionBotDelisted,omitempty"`
	// AUCTION-SALES:auction_sales_list 返回的成交记录数组。
	AuctionSales       json.RawMessage `json:"auctionSales,omitempty"`
	AuctionSaleHistory json.RawMessage `json:"auctionSaleHistory,omitempty"`
	// GOLD-CONSIGN-SALES:gold_consign_sales_list 返回的成交记录。
	GoldConsignSales  json.RawMessage        `json:"goldConsignSales,omitempty"`
	AbyssRarityTables map[string][][]float64 `json:"abyssRarityTables,omitempty"`

	// MAGIC-BOX-OVERRIDE:magic_box_override_* action 的返回。
	MagicBoxOverrideCount int                                  `json:"magicBoxOverrideCount,omitempty"`
	MagicBoxOverrides     map[string][]MagicBoxRewardGroupJSON `json:"magicBoxOverrides,omitempty"`
}
