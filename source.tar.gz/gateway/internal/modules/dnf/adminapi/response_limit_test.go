package adminapi

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

// TestLargeReportResponsesAccepted 是成交记录查询故障的回归测试。
//
// 历史：2026-11-18 曾有 GM「成交记录查询」报 invalid game runtime response ——
// 旧实现把响应限制在 64KB，而线上 auction_sale_history 有 1325 行（约 300KB）。
// 我方曾修成「报表 action 白名单 2MB」；上游随后用更彻底的方案解决了同一问题：
// 所有 action 统一上限 maxAdminResponseBytes = 4MB。按协作工作流 5.1，
// 上游已修同样问题时接受上游版本、删掉我方重复实现 —— 本测试随之改为
// 验证上游的 4MB 上限，防回归。
func TestLargeReportResponsesAccepted(t *testing.T) {
	// 300KB 成交流水（原故障规模），必须能完整取回。
	big := strings.Repeat("x", 300<<10)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req Request
		_ = json.NewDecoder(r.Body).Decode(&req)
		resp := Response{Version: Version, OK: true}
		if req.Action == "auction_sale_history" {
			resp.AuctionSaleHistory = json.RawMessage(`"` + big + `"`)
		}
		_ = json.NewEncoder(w).Encode(resp)
	}))
	defer server.Close()
	c, _ := NewClient(server.URL+Path, strings.Repeat("x", 32))

	r, err := c.Call(context.Background(), Request{Action: "auction_sale_history"})
	if err != nil {
		t.Fatalf("300KB 成交流水应被接受，实际: %v —— 若报 invalid game runtime response 说明响应上限又被调小了", err)
	}
	if len(r.AuctionSaleHistory) < 300<<10 {
		t.Fatalf("大响应被截断: got %d bytes", len(r.AuctionSaleHistory))
	}
}

// TestOversizedResponseStillRejected 验证 4MB 上限仍在（不是无限读取）。
func TestOversizedResponseStillRejected(t *testing.T) {
	huge := strings.Repeat("x", int(maxAdminResponseBytes)+1024)
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewEncoder(w).Encode(Response{Version: Version, OK: true, Error: huge})
	}))
	defer server.Close()
	c, _ := NewClient(server.URL+Path, strings.Repeat("x", 32))

	if _, err := c.Call(context.Background(), Request{Action: "online"}); err == nil {
		t.Fatal("超过 4MB 的响应仍应被拒绝")
	}
}
