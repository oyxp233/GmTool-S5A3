// gmrebuild rebuilds the GM console's offline PVF indexes.
//
// 为什么需要单独一个命令：GM 启动时 OpenDisk() 会校验索引头里的 PVF SHA256，
// 不匹配直接报 "PVF disk index unavailable; build it offline first"；
// 而现有 GMIndex 只建 profession / expertJob，没有暴露 BuildDiskIndex，
// 也不会生成 items.json（缺这个文件 GM 直接 exit 1）。
//
// 换 PVF 的完整姿势：
//
//	gmrebuild -all -pvf /path/Script.pvf -sha256 <64位> \
//	          -index /path/indexes/pvf.bin -items /path/indexes/items.json
//
// -index 指定的文件必须**不存在**（BuildDiskIndex 的既有契约），
// 所以换档前先把旧 pvf.bin 改名备份。
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	platformpvf "dnf90.local/gateway/internal/platform/pvf"
	"dnf90.local/gateway/internal/services/gmtool"
)

func main() {
	pvf := flag.String("pvf", "", "approved Script.pvf path")
	hash := flag.String("sha256", "", "full approved PVF SHA256")
	index := flag.String("index", "", "pvf.bin output path (must not exist)")
	items := flag.String("items", "", "items.json path (summary beside the other indexes)")
	all := flag.Bool("all", false, "also rebuild item details / professions / quests / expert jobs")
	skipDetails := flag.Bool("skip-details", false, "skip the slow item-details build (keep the rest)")
	summaryOnly := flag.Bool("summary-only", false, "only rebuild items.json (summary); leave item-details untouched")
	flag.Parse()
	if flag.NArg() != 0 || *pvf == "" || *hash == "" || *index == "" || *items == "" {
		flag.Usage()
		os.Exit(2)
	}
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	log := func(msg string, args ...any) {
		fmt.Fprintf(os.Stderr, msg+"\n", args...)
	}

	// 1) pvf.bin：目录索引，BuildDiskIndex 自己解析 PVF，不依赖任何已有索引。
	// 已经存在就复用 —— BuildDiskIndex 的契约是 target 不能存在，
	// 但换档重跑时 pvf.bin 往往已经建好（上一次只差 items.json），没必要删了重来。
	if _, err := os.Stat(*index); err == nil {
		fmt.Printf("pvf.bin exists, reuse: %s\n", *index)
	} else {
		if err := platformpvf.BuildDiskIndex(ctx, *pvf, *hash, *index); err != nil {
			fmt.Fprintln(os.Stderr, "disk index:", err)
			os.Exit(1)
		}
		if info, err := os.Stat(*index); err == nil {
			fmt.Printf("pvf.bin ok: %s (%d bytes)\n", *index, info.Size())
		}
	}
	if !*all {
		return
	}

	// 2) 用刚建好的索引打开归档，再建其余索引。
	source, err := platformpvf.OpenDisk(*pvf, *index, *hash)
	if err != nil {
		fmt.Fprintln(os.Stderr, "open disk:", err)
		os.Exit(1)
	}
	if *summaryOnly {
		// 只重建摘要：给索引加字段后用这个，比 -all 快几个数量级。
		if err := gmtool.RebuildItemSummary(ctx, source, *items, log); err != nil {
			fmt.Fprintln(os.Stderr, "item summary:", err)
			os.Exit(1)
		}
		fmt.Println("item summary rebuilt:", *items)
		return
	}

	// items.json 由 BuildItemDetails 内部的 itemIndex.build() 写出。
	// 它同时会生成 217MB 的 item-details，单线程扫全档约 25KB/s（两小时级），
	// 所以换档时通常先 -skip-details 把 GM 拉起来，item-details 之后再单独补。
	if !*skipDetails {
		if _, err := gmtool.BuildItemDetails(ctx, source, *items, log); err != nil {
			fmt.Fprintln(os.Stderr, "item details:", err)
			os.Exit(1)
		}
	} else if _, err := os.Stat(*items); err != nil {
		fmt.Fprintln(os.Stderr, "skip-details 需要已存在的 items.json:", err)
		os.Exit(1)
	} else {
		fmt.Printf("items.json exists, reuse: %s\n", *items)
	}
	if _, err := gmtool.BuildProfessionIndex(ctx, source, *items); err != nil {
		fmt.Fprintln(os.Stderr, "profession:", err)
		os.Exit(1)
	}
	if _, err := gmtool.BuildQuestIndex(ctx, source, *items); err != nil {
		fmt.Fprintln(os.Stderr, "quest:", err)
		os.Exit(1)
	}
	if _, err := gmtool.BuildExpertJobIndex(ctx, source, *items); err != nil {
		fmt.Fprintln(os.Stderr, "expert job:", err)
		os.Exit(1)
	}
	fmt.Println("all indexes rebuilt")
}
